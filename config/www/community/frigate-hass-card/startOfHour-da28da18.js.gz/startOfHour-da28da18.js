import{d2 as t}from"./card-73ddfee6.js";function s(s){const n=t(s);return n.setMinutes(59,59,999),n}function n(s){const n=t(s);return n.setMinutes(0,0,0),n}export{s as e,n as s};
